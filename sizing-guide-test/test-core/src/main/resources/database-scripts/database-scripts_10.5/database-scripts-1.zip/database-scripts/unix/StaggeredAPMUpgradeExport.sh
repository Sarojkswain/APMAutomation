#!/bin/sh

# This exports the tables in the cemdb database for the upgrade process

set -e

dbinstalldir=$1
dbbakfile=$2
dbname=$3
dbadminuser=$4
dbadminpwd=$5

if [ $# -lt 5 ]; then
  echo "Arguments required <dbinstalldir> <dbbakfile> <dbname> <dbadminuser> <dbadminpwd> <dbport <optional>>"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 6 ]; then
  dbport=$6
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"

# Get the database version from the domain entry with id 1.
db_version=$(PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" psql -q -t --pset format=unaligned -p $dbport -d "$dbname" -c 'select ts_db_versions from ts_domains where ts_id=1;')

if [ -z "$db_version" ]; then
	echo "$pgm: database version is not defined" 1>&2
	exit 1
fi

if [ "$db_version" != "5.0.0.0" ]; then
  echo "The script can only be run against a database of schema version 5.0"
  exit
fi

# export the tables
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_dump -D -Ft --file="$dbbakfile" --table=apm_agent --table=apm_edge --table=apm_metric_path --table=apm_owner --table=apm_vertex --table=apm_vertex_logical_equivalence --table=apm_vertex_type --table=ts_apps --table=ts_tran_def_groups --table=ts_transet_groups --table=ts_transets --table=ts_tranunits --table=ts_trancomps --table=ts_params --table=ts_transetgroup_transets_map --table=ts_bizdef_filters --table=ts_defect_defs --table=ts_recording_components --table=ts_recording_sessions --table=ts_monitors --port=$dbport --username="$dbadminuser" "$dbname"
