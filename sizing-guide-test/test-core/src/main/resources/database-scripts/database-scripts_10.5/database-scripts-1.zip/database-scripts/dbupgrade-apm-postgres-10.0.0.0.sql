-- appmap
CREATE TABLE appmap_api_keys(
		id INTEGER NOT NULL,
		username VARCHAR(256) NOT NULL,
		date_created TIMESTAMP NOT NULL,
		date_expired TIMESTAMP,
		hashed_token CHAR(64) NOT NULL,
		description VARCHAR(256),
		PRIMARY KEY(id)
);

ALTER TABLE appmap_api_keys
    ADD CONSTRAINT appmap_api_keys_unique UNIQUE(hashed_token);

CREATE SEQUENCE seq_appmap_api_key_id MINVALUE 1;
ALTER SEQUENCE seq_appmap_api_key_id owned by appmap_api_keys.id;


CREATE TABLE appmap_model_vertices (
        external_id VARCHAR(1024) PRIMARY KEY,
        update_time TIMESTAMP NOT NULL,
        data TEXT
);

CREATE INDEX appmap_model_vertices_idx ON appmap_model_vertices(update_time DESC);


ALTER TABLE appmap_id_mappings ALTER COLUMN external_id TYPE VARCHAR(2048);

-- /appmap
