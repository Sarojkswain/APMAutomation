#!/bin/sh

# This script is run by the db import program to finish up the import.
postgresDbServer=$1
postgresDbInstallDir=$2
postgresDbName=$3
postgresDbUser=$4
postgresDbPassword=$5
postgresDBPort=$6
postgresDBScriptsVer=$7
desiredDBVersion="5.0.0.0"

if [ $# -lt 7 ]; then
  echo "Required arguments <dbserverhostip> <dbinstalldir> <dbname> <dbuser> <dbpassword> <dbport> <dbScriptVer<optional>>"
  exit
fi

if [ -z "$7" ]; then
   postgresDBScriptsVer=5.0.0
fi

# db versions are of the form: d.d.d; create table scripts are only available for major versions, i.e. d.d.0
postgresDBScriptsVer=$(echo "$postgresDBScriptsVer" | sed 's/\([0-9][0-9]*\.[0-9][0-9]*\.\)[0-9][0-9]*[\.]*[0-9]*/\10/')

# cd to this program's directory because that's where the other scripts live
dir="$(dirname $0)"
if [ -n "$dir" ]; then cd "$dir" || exit 1; fi

echo Adding indexes...
sh ./addindexes-postgres.sh $postgresDbServer $postgresDbInstallDir $postgresDbName $postgresDbUser $postgresDbPassword $postgresDBPort $postgresDBScriptsVer 1>/dev/null

echo Adding constraints...
sh ./addconstraints-postgres.sh $postgresDbServer $postgresDbInstallDir $postgresDbName $postgresDbUser $postgresDbPassword $postgresDBPort $postgresDBScriptsVer 1>/dev/null

echo Adding views...
sh ./addviews-postgres.sh $postgresDbServer $postgresDbInstallDir $postgresDbName $postgresDbUser $postgresDbPassword $postgresDBPort $postgresDBScriptsVer 1>/dev/null

export PATH="$postgresDbInstallDir/bin:$PATH"
echo Upgrading sequences...
sequenceScriptFile=../dbupdate-sequences-postgres-$postgresDBScriptsVer.sql
if [ -r "$sequenceScriptFile" ]; then
  PGUSER="$postgresDbUser" PGPASSWORD="$postgresDbPassword" psql -h $postgresDbServer -p "$postgresDBPort" -d "$postgresDbName" -f "$sequenceScriptFile" 1>/dev/null
fi

echo Doing db upgrades...
sh ./dbupgrade-postgres.sh $postgresDbServer $postgresDbInstallDir $postgresDbName $postgresDbUser $postgresDbPassword $desiredDBVersion $postgresDBPort 1>/dev/null
