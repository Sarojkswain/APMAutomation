--- this file contains SQL commands run daily (after the backup is done)

vacuum;
