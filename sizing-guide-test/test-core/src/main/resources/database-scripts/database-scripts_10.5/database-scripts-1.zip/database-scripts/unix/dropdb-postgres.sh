#!/bin/bash

# This drops the cemdb PostgreSQL database

set -e

dbserverhost=$1
dbinstalldir=$2
dbname=$3
dbserviceuser=$4
dbservicepwd=$5

if [ $# -lt 5 ]; then
  echo "Arguments required <dbserverhostip> <dbinstalldir> <dbname> <dbuser> <dbpwd> <dbport <optional>>"
  echo "dbinstalldir: complete path where the database is installed excluding the bin dir. "
  echo "eg: /opt/database/postgres/8.3-community "
  exit
fi


# set the dbport to default 5432
if [ $# -eq 6 ]; then
  dbport=$6
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$dbinstalldir/bin/64:$PATH"

# See if db already exists
cmd="PGUSER="$dbserviceuser" PGPASSWORD="$dbservicepwd" psql -d template1 -q -t --pset format=unaligned -h $dbserverhost -p $dbport -c \"select count(1) from pg_catalog.pg_database where datname = '$dbname'\""
db_count=`eval $cmd`

# Drop the database if it exists
if [ $db_count -eq 1 ] ; then
    if PGUSER="$dbserviceuser" PGPASSWORD="$dbservicepwd" psql -h $dbserverhost -p $dbport -d "$dbname" -f /dev/null 2> /dev/null; then
       echo 'Dropping database "'$dbname'"'
       PGUSER="$dbserviceuser" PGPASSWORD="$dbservicepwd" dropdb -h $dbserverhost -p $dbport "$dbname"
  
       # see if we were successful in dropping the db, if not AND it already exits, exit
       if [ "$?" -eq "1" ]; then
           exit 1
       fi  
    fi
fi  


