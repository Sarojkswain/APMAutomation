#!/usr/bin/env python
# the line above is for the UNIX environment
#
# Add the application id report_param value (see TT xxxx)

import os
import sys
import time
import mx.ODBC.unixODBC

dsn = 'TSDSN'
uid = 'admin'
pwd = 'quality'

# process any cmd line args
args = sys.argv[1:]
if (len(args) > 0):
	dsn = args[0]
if (len(args) > 1):
	uid = args[1]
if (len(args) > 2):
	pwd = args[2]

# connect to the database
dbcnx = mx.ODBC.unixODBC.Connect(dsn, uid, pwd)
dbcur = dbcnx.cursor()

# get the version_info, ts_report_def_id, ts_value (tranSetGroupId) from ts_report_def_param_values
# for the reports that have ts_param_key_id = 17 (TranSetGroup)
dbcur.execute('SELECT version_info, ts_report_def_id, ts_value FROM ts_report_def_param_values where ts_param_key_id = 17')
tranSetGrpValues = dbcur.fetchall()

# get the biggest pk id used
dbcur.execute('SELECT MAX(ts_id) FROM ts_report_def_param_values')
id = dbcur.fetchone()
if (id[0] is None):
	pk_id = 600000000000000000
else:
	pk_id = id[0] + 1

# add applicatoin id param value for each TranSetGroup found
for tranSetGrpValue in tranSetGrpValues:
	version = tranSetGrpValue[0]
        def_id = tranSetGrpValue[1]
        tranSetGroupId = long(tranSetGrpValue[2])
   
        # get the application id for the tranSetGroupId
        if (tranSetGroupId == 0):
                app_id = 0
        else: 
            dbcur.execute('SELECT tdg.ts_app_id FROM ts_transet_groups AS tsg JOIN ts_tran_def_groups AS tdg ON tsg.ts_trandef_group_id = tdg.ts_id WHERE tsg.ts_id = %s' % (tranSetGroupId))
            app = dbcur.fetchone()
            app_id = app[0]

        # add a new param value for the application id
        print 'Adding application id %d for tranSetGroupId  %d' % (app_id, tranSetGroupId)
        dbcur.execute('INSERT INTO ts_report_def_param_values (ts_id, version_info, ts_param_key_id, ts_report_def_id, ts_value, ts_soft_delete) values (%s, %s, 28, %s, %s, FALSE)' % (pk_id, version, def_id, app_id))

        # increment the pk id
        pk_id += 1

dbcnx.commit()
