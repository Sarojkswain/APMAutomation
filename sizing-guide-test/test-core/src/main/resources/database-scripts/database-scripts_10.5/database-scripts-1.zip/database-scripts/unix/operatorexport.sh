#!/bin/sh
# runs the operator export program

postgresServer=$1
postgresPort=$2
postgresDbName=$3
postgresUser=$4
postgresPwd=$5
exportType=$6
exportToDir=$7

echo "postgresServer=$1"
echo "postgresPort=$2"
echo "postgresDbName=$3"
echo "postgresUser=$4"
echo "postgresPwd=$5"
echo "exportType=$6"
echo "exportToDir=$7"

if [ $# -lt 7 ]; then
  echo "Required arguments <dbhostIP> <dbport> <dbname> <dbuser> <dbpassword> <exportType(eem/local/both> <exportToDir>"
  exit
fi


if [ -z "$JAVA_HOME" ]; then
  echo "JAVA_HOME is not set.  Please set the environment variable JAVA_HOME to point to your JRE (1.6 or higher) root folder."
  exit
fi


lib_dir=../lib

class_dir=../:$lib_dir/com.wily.apm.dbtools_10.5.1.jar:$lib_dir/org.apache.jakarta_log4j_1.2.15.jar:$lib_dir/postgresql-9.2-1003.jdbc4.jar:$lib_dir/commons-lang-2.1.jar:$lib_dir/commons-configuration-1.1.jar:$lib_dir/castor-1.3.jar:$lib_dir/castor-1.3-core.jar:$lib_dir/commons-logging-1.0.4.jar

java_vm_args="-Dlog4j.configuration=../../common/config/log4j-dbtools.properties"

# run the import program
$JAVA_HOME/bin/java -Xms256M -Xmx1024M -cp $class_dir $java_vm_args com.wily.apm.dbtools.operatorexport.OperatorExport -dbHost $postgresServer -dbport $postgresPort -dbname $postgresDbName -dbuser $postgresUser -dbpassword $postgresPwd -exportType $exportType -exportToDir $exportToDir
