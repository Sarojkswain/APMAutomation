#!/bin/sh

# This sets up the tables in the cemdb database for PostgreSQL.

set -e

dbserverip=$1
dbinstalldir=$2
dbname=$3
dbadminuser=$4
dbadminpwd=$5
dbversion=$6

if [ $# -lt 6 ]; then
  echo "Arguments required <dbserverip> <dbinstalldir> <dbname> <dbadminuser> <dbadminpwd> <schemaversion> [dbport]"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 7 ]; then
  dbport=$7
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"

echo 'Upgrading 3.3.3 to 3.3.4'
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d "$dbname" -f "../dbupgrade-postgres-3.3.3.sql"

# ignore any errors
exit 0
