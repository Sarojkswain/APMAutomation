#!/usr/bin/env python
# the line above is for the UNIX environment
#
# Copyright 2002-2006 Wily Technology, Inc. All rights reserved.  This product or document is 
# protected by copyright and distributed under licenses restricting its use, copying,
# distribution, decompilation, or transmission in any form or by any means without
# the prior written authorization of Wily Technologies, Inc.

# This module contains a program to upgrade a major database version, e.g. 3.3.0, to a minor
# database version, e.g. 3.3.1.  It reads the dbupgrade-postgres-3.3.x.sql files, extracts
# the database schema statements (create table, alter table, etc) and executes them.
#
# python dbupgrade-postgres.py <db-version> <dsn> <user> <password>

import re
import sys
import os.path
import mx.ODBC.unixODBC

# parse db version number of the form: d.d.d
def getDbVersions(dbVersion):
	m = re.match(r'(\d+?)\.(\d+?)\.(\d+?)\.(\d+?)$', dbVersion)
	if (not m):
		m = re.match(r'(\d+?)\.(\d+?)\.(\d+?)$', dbVersion)
	if (not m):
		raise ValueError, "Invalid database version"		
	return m.groups()

# returns true if a string starts with any of a list of strings
def startsWith(str, strs):
	for s in strs:
		if (str.startswith(s)): return True
	return False

# read the rest of a postgres sql stmt
def getSqlStmt(fd, stmt):
	while (not stmt.rstrip().endswith(';')):
		line = fd.readline()
		if (not line): break
		stmt += line
	return stmt

# read a .sql file and return a list of all database schema statements (create table, drop view etc)
def getSqlSchemaStmts(fd):
	stmts = []
	while True:
		line = fd.readline()
		if (not line): break
		line = line.lstrip()
		if (startsWith(line, ('alter ', 'create ', 'drop '))):
			stmts += [getSqlStmt(fd, line)]
	return stmts

def doUpgrade():
	if (len(sys.argv) < 5):
		raise ValueError, "Missing required command line parameters"

	# get the command line parameters
	dbVersion = sys.argv[1]
	dbVersions = getDbVersions(dbVersion)
	dsn = sys.argv[2]
	usr = sys.argv[3]
	pwd = sys.argv[4]

	# get a connection to the Tess database
	try:
		dbcnx = mx.ODBC.unixODBC.Connect(dsn, usr, pwd)
		dbcur = dbcnx.cursor()		
	except mx.ODBC.unixODBC.mxODBC.Warning:
		pass

	# read and execute the schema statements in each db upgrade file
	for i in xrange(0, int(dbVersions[2])):
		sqlFileName = '../dbupgrade-postgres-%s.%s.%d.sql' % (dbVersions[0], dbVersions[1], i)
		if (os.path.exists(sqlFileName)):
			print 'Upgrading using %s' % (sqlFileName)
			fd = open(sqlFileName)
			stmts = getSqlSchemaStmts(fd)
			for stmt in stmts: dbcur.execute(stmt)
			if (stmts): dbcnx.commit()
		
		j = 0
		while (True):
			sqlFileName = '../dbupgrade-postgres-%s.%s.%d.%d.sql' % (dbVersions[0], dbVersions[1], i, j)	
			if (os.path.exists(sqlFileName)):
				print 'Upgrading using  %s' % (sqlFileName)
				fd = open(sqlFileName)
				stmts = getSqlSchemaStmts(fd)
				for stmt in stmts: dbcur.execute(stmt)
				if (stmts): dbcnx.commit()
			else:
				break
			j = j + 1

	try:
		dbcnx.close()
	except:
		pass


#-----  main program starts here -----

try:
	doUpgrade()
except Exception, ex:
	print ex
