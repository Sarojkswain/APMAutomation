-- ACA
--   Tables

CREATE TABLE aca_user
(
  user_id character varying(256) not null,
  realm_id character varying(256) not null,
  searchable_attrib1 character varying(256) null,
  searchable_attrib2 character varying(256) null,
  searchable_attrib3 character varying(256) null,
  searchable_attrib4 character varying(256) null,
  searchable_attrib5 character varying(256) null,
  attributes text null,
  realm_attributes text null,
  last_login_time timestamp without time zone NULL,
  last_update timestamp without time zone NOT NULL,
  CONSTRAINT aca_user_pk PRIMARY KEY (user_id)
);

CREATE TABLE aca_group
(
  group_id character varying(256) not null,
  realm_id character varying(256) not null,
  searchable_attrib1 character varying(256) null,
  searchable_attrib2 character varying(256) null,
  searchable_attrib3 character varying(256) null,
  searchable_attrib4 character varying(256) null,
  searchable_attrib5 character varying(256) null,
  attributes text null,
  realm_attributes text null,
  last_update timestamp without time zone NOT NULL,
  CONSTRAINT aca_group_pk PRIMARY KEY (group_id)
);

CREATE TABLE aca_user_group
(
  user_id character varying(256) not null,
  group_id character varying(256) not null,
  last_update timestamp without time zone NOT NULL,
  CONSTRAINT aca_user_group_pk PRIMARY KEY (user_id, group_id)
);

CREATE TABLE aca_acl
(
  acl_id numeric not null,
  service_provider_id character varying(256) NOT NULL,
  service_provider_instance_id character varying(256) NOT NULL,
  resource_id character varying(256) NOT NULL,
  group_id character varying(256) NULL,
  user_id character varying(256) NULL,
  resource_type_id character varying(10) NOT NULL,
  capabilities_allow text NULL,
  capabilities_grant text NULL,
  last_update timestamp without time zone NOT NULL,
  CONSTRAINT aca_acl_pk PRIMARY KEY (acl_id),
  CONSTRAINT aca_acl_user_xor_group CHECK ( ( group_id is null and user_id is not null ) or (group_id is not null and user_id is null) ),
  CONSTRAINT aca_acl_resource_type_id CHECK ( resource_type_id = 'regex' or resource_type_id = 'literal' )
);

create table aca_audit(
  update_time timestamp without time zone NOT NULL,
  user_id character varying(256) NOT NULL,
  table_name character varying(256) NOT NULL,
  change_from text null,
  change_to text null
);

--   Indices

CREATE INDEX aca_user_searchable_attrib1_idx ON aca_user (searchable_attrib1);
CREATE INDEX aca_user_searchable_attrib2_idx ON aca_user (searchable_attrib2);
CREATE INDEX aca_user_searchable_attrib3_idx ON aca_user (searchable_attrib3);
CREATE INDEX aca_user_searchable_attrib4_idx ON aca_user (searchable_attrib4);
CREATE INDEX aca_user_searchable_attrib5_idx ON aca_user (searchable_attrib5);

CREATE INDEX aca_group_searchable_attrib1_idx ON aca_group (searchable_attrib1);
CREATE INDEX aca_group_searchable_attrib2_idx ON aca_group (searchable_attrib2);
CREATE INDEX aca_group_searchable_attrib3_idx ON aca_group (searchable_attrib3);
CREATE INDEX aca_group_searchable_attrib4_idx ON aca_group (searchable_attrib4);
CREATE INDEX aca_group_searchable_attrib5_idx ON aca_group (searchable_attrib5);

CREATE INDEX aca_user_group_group_id ON aca_user_group (group_id);

CREATE UNIQUE INDEX aca_acl_ak1 ON aca_acl(service_provider_id, service_provider_instance_id, resource_id, group_id);
CREATE UNIQUE INDEX aca_acl_ak2 ON aca_acl(service_provider_id, service_provider_instance_id, resource_id, user_id);

CREATE INDEX aca_audit_update_time_idx ON aca_audit (update_time);

--    Constraints

alter table aca_user_group
	add CONSTRAINT aca_user_group_user_id
	FOREIGN KEY ( user_id )
	REFERENCES aca_user ( user_id ) on delete cascade;

alter table aca_user_group
	add CONSTRAINT aca_user_group_group_id
	FOREIGN KEY ( group_id )
	REFERENCES aca_group ( group_id ) on delete cascade;

--    Sequences

CREATE SEQUENCE sq_aca_acl MINVALUE 1;
ALTER SEQUENCE sq_aca_acl owned by aca_acl.acl_id;

ALTER TABLE appmap_vertices ALTER COLUMN vertex_name TYPE varchar(1024);
ALTER TABLE appmap_vertices ALTER COLUMN business_service TYPE varchar(1024);

