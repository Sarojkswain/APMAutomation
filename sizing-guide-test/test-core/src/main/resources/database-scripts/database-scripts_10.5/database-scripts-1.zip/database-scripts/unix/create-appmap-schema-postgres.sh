#!/bin/bash

# This script sets up the App Map tables in the cemdb database for PostgreSQL.
# $1 = optional database version

set -e

dbinstalldir=$1
dbname=$2
dbadminuser=$3
dbadminpwd=$4
dbversion=$5

if [ $# -lt 5 ]; then
  echo "Arguments required <dbinstalldir> <dbname> <dbadminuser> <dbadminpwd> <schemaversion>"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 6 ]; then
  dbport=$6
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"

if [ ! -e "../create-appmap-tables-postgres-$dbversion.sql" ]; then
  echo "SQL scripts to create schema version $dbversion not found"
  exit
fi

APP_MAP="App Map"

echo "$APP_MAP Schema $dbversion initialization and Creation of $APP_MAP tables started...."

PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../create-appmap-tables-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../create-appmap-sequences-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../add-appmap-indexes-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../add-appmap-constraints-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../init-appmap-db-postgres-$dbversion.sql"
echo "$APP_MAP Schema $dbversion initialization is completed"
