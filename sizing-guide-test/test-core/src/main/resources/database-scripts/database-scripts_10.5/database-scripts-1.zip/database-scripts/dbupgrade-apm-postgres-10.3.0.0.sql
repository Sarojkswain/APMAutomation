ALTER TABLE appmap_id_mappings ALTER COLUMN external_id TYPE varchar(2048);
ALTER TABLE appmap_vertices ALTER COLUMN vertex_name TYPE varchar(2048);
ALTER TABLE appmap_vertices ALTER COLUMN business_service TYPE varchar(2048);
ALTER TABLE appmap_attribs ALTER COLUMN attrib_name TYPE varchar(512);
ALTER TABLE appmap_attribs ALTER COLUMN value TYPE varchar(2048);
ALTER TABLE appmap_model_vertices ALTER COLUMN external_id TYPE varchar(2048);

CREATE SEQUENCE seq_appmap_mom_id_number MINVALUE 1;

INSERT INTO appmap_id_mappings (vertex_id, external_id, type)
    SELECT -1, 'CA_APM_INTERNAL_METRIC', 'M' WHERE NOT EXISTS(SELECT 1 FROM appmap_id_mappings WHERE vertex_id = -1);

ALTER TABLE appmap_edges ADD COLUMN backend_id INTEGER;
UPDATE appmap_edges SET backend_id = 0;
ALTER TABLE appmap_edges DROP CONSTRAINT appmap_edges_pkey;
ALTER TABLE appmap_edges ADD PRIMARY KEY (transaction_id, start_time, source_id, target_id, backend_id);

alter table appmap_edges
    add constraint appmap_backend_fk4
    foreign key (backend_id)
    references appmap_id_mappings on delete cascade; 

DROP INDEX  appmap_edges1_idx;
CREATE UNIQUE INDEX appmap_edges1_idx ON appmap_edges(fork, end_time, start_time, source_id, target_id, transaction_id, backend_id);
CREATE INDEX appmap_edges_fk4_idx ON appmap_edges(fork, backend_id, end_time, start_time);




-- assistedtriage
CREATE TABLE at_stories_pivot
(
        story_id int not null,
       	PRIMARY KEY (story_id)
);

CREATE TABLE at_evidences
(
        story_id int NOT NULL,
        vertex_id varchar(300) NOT NULL,
        type varchar(30) NOT NULL,
        occ_index int NOT NULL,
        start_time timestamp  NOT NULL,
        end_time timestamp NOT NULL,
        fork BIGINT NOT NULL,
        latest int NOT NULL,
        statements text,
        primary key (story_id, vertex_id, type, occ_index),
        foreign key (story_id) references at_stories_pivot(story_id) on delete cascade
);
CREATE TABLE at_stories
(
        story_id int NOT NULL,
        start_time timestamp  NOT NULL,
        end_time timestamp NOT NULL,
        fork BIGINT NOT NULL,
        latest int NOT NULL,
        statements text,
        primary key (story_id, start_time),
        foreign key (story_id) references at_stories_pivot(story_id) on delete cascade
);
CREATE INDEX at_evidences_trange_fork_idx ON at_evidences(fork, end_time, start_time);
CREATE INDEX at_evidences_latest_idx ON at_evidences(story_id, vertex_id, type, latest);
CREATE INDEX at_stories_trange_fork_idx ON at_stories(fork, end_time, start_time);
CREATE INDEX at_stories_trange_fork_latest on at_stories(fork, latest, end_time, start_time);

CREATE SEQUENCE sq_at_stories_pivot MINVALUE 1;
ALTER SEQUENCE sq_at_stories_pivot owned by at_stories_pivot.story_id;
-- /assistedtriage
