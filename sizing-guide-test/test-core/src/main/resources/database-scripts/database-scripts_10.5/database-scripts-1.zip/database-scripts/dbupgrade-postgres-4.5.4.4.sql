-- update database from 4.5.4.4 to 4.5.4.5
 
-- Updating database version
update ts_domains set ts_db_versions='4.5.4.5';
