-- update database from 5.0.0.0 to 5.0.0.1
 
-- Updating database version
update ts_domains set ts_db_versions='5.0.0.1';
