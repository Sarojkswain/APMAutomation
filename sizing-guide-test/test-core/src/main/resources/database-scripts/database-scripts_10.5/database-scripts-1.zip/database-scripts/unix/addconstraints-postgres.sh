#!/bin/bash

# This sets up the tables in the cemdb database for PostgreSQL.

set -e

postgresDbServer=$1
postgresDbInstallDir=$2
postgresDbName=$3
postgresDbUser=$4
postgresDbPassword=$5
postgresDBPort=$6
postgresDBScriptsVer=$7

if [ $# -lt 7 ]; then
  echo "Required arguments <dbserverhostip> <dbinstalldir> <dbname> <dbuser> <dbpassword> <dbport> <dbScriptVer<optional>>"
  exit
fi

export PATH="$postgresDbInstallDir/bin:$PATH"

# set the database version
if [ $# -eq 7 ]; then
  postgresDBScriptsVer=$7
else
  postgresDBScriptsVer="5.0.0"
fi

echo 'Adding constraints'
PGUSER=$postgresDbUser PGPASSWORD="$postgresDbPassword" psql -h $postgresDbServer -d $postgresDbName -p "$postgresDBPort" -f "../addconstraints-postgres-$postgresDBScriptsVer.sql"

