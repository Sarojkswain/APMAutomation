#!/bin/bash

set -e

postgresDbInstallDir=$1
postgresDbName=$2
postgresDbUser=$3
postgresDbPassword=$4
postgresDBPort=$5

if [ $# -lt 5 ]; then
  echo "Required arguments <dbinstalldir> <dbname> <dbuser> <dbpassword> <dbport>"
  exit
fi

export PATH="$postgresDbInstallDir/bin:$PATH"

echo 'Adding user constraints'
PGUSER=$postgresDbUser PGPASSWORD="$postgresDbPassword" psql -d $postgresDbName -p "$postgresDBPort" -f "../drop-user-constraints.sql"

