#!/bin/bash

# This script sets up the App Map tables in the cemdb database for PostgreSQL.
# $1 = optional database version
set -e

dbinstalldir=$1
dbname=$2
dbadminuser=$3
dbadminpwd=$4
dbport=$5
dbversion=$6

if [ $# -lt 4 ]; then
  echo "Required arguments [dbinstalldir] [dbname] [dbuser] [dbpassword] [dbport<optional: [default :5432]>] [dbScriptVer <optional: [default:5.0.0]>]"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 5 ]; then
  dbport=$5
else
  dbport="5432"
fi

# set the dbversion to default 5.0.0
if [ $# -eq 6 ]; then
  dbversion=$6
else
  dbversion="5.0.0"
fi

export PATH="$dbinstalldir/bin:$PATH"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../drop-apm-indexes-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../drop-apm-constraints-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../drop-apm-tables-postgres-$dbversion.sql"
