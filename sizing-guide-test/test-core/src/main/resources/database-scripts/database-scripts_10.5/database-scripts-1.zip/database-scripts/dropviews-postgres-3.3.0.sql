-- drop static views

drop view view_biz_event_metadata;
drop view TranSetGroupSlaPerformanceTimeSlaView;
drop view UserGroupSlaPerformanceTimeSlaView;
