##!/usr/bin/env python
# the line above is for the UNIX environment
#
# cleanup ts_user_logins_map so that primary key can be changed from
# (app id, user id, login name) to (app id, login name). see bug 952

import os
import sys
import mx.ODBC.unixODBC


def final_cleanup(dbcnx, dbcur, ignore_apps, app_map):

	# make sure login is correct if case insensitive
	print "making login case correct"
	if (ignore_apps):
		case_sensitive = app_map[1]
		if (not case_sensitive):
			dbcur.execute("update ts_user_logins_map set ts_login_name=lower(ts_login_name)")
	else:
		appIds = []
		for app in app_map.items():
			aid = app[0]
			case_sensitive = app[1]
			if (not case_sensitive): appIds += [aid]
		if (len(appIds) > 0):
			dbcur.execute("update ts_user_logins_map set ts_login_name = lower(ts_login_name) where ts_app_id in %s" % str(tuple(appIds)).replace('L', '').replace(',)', ')'))

	# delete any soft deleted rows (except for the unspecified user)
	print "removing soft deleted rows in ts_user_logins_map"
	dbcur.execute("update ts_user_logins_map set ts_soft_delete=false where lower(ts_login_name)='unspecified'")
	dbcnx.commit()
	dbcur.execute("delete from ts_user_logins_map where ts_soft_delete=true")
	dbcnx.commit()


dsn = 'TSDSN'
uid = 'admin'
pwd = 'quality'
args = sys.argv[1:]
if (len(args) > 0):
	dsn = args[0]
if (len(args) > 1):
	uid = args[1]
if (len(args) > 2):
	pwd = args[2]

dbcnx = mx.ODBC.unixODBC.Connect(dsn, uid, pwd)
dbcur = dbcnx.cursor()

# get case sensitivity of each app
dbcur.execute("select ts_id,ts_case_sensitivity_login_name from ts_apps")
apps = dbcur.fetchall()
app_map = {}
for app in apps: app_map[app[0]] = int(app[1])

# experience has shown that there can be 10,000s to 100,000s of duplicate logins
# the deleted login names are written to a file for later restoration and then removed so the PK can be changed
# from (ts_app_id,ts_user_id,ts_login_name) to (ts_app_id,ts_login_name)

dbcur.execute('select ts_ignore_apps_in_user_recognition from ts_domains where ts_id=1')
ignore_apps = int(dbcur.fetchall()[0][0])
if (ignore_apps):
	print "ignoring apps in user recognition"
	case_sensitive = app_map[1]
	print 'default app is case',
	if (case_sensitive):
		print 'sensitive'
		dbcur.execute('select ts_user_id,ts_login_name from ts_user_logins_map where ts_login_name in (select ts_login_name from ts_user_logins_map group by ts_login_name having count(*) > 1)')
	else:
		print 'insensitive'
		dbcur.execute('select ts_user_id,ts_login_name from ts_user_logins_map where lower(ts_login_name) in (select lower(ts_login_name) from ts_user_logins_map group by lower(ts_login_name) having count(*) > 1)')
	logins = dbcur.fetchall()
else:
	# get dups for case sensitive apps
	dbcur.execute('select ts_user_id,ts_login_name from ts_user_logins_map where ts_login_name in (select ts_login_name from ts_user_logins_map where ts_app_id in (select ts_id from ts_apps where ts_case_sensitivity_login_name=true) group by ts_app_id,ts_login_name having count(*) > 1)')
	logins = dbcur.fetchall()

	# get dups for case insensitive apps
	dbcur.execute('select ts_user_id,ts_login_name from ts_user_logins_map where lower(ts_login_name) in (select lower(ts_login_name) from ts_user_logins_map where ts_app_id in (select ts_id from ts_apps where ts_case_sensitivity_login_name=false) group by ts_app_id,lower(ts_login_name) having count(*) > 1)')
	logins += dbcur.fetchall()

# punt if no duplicates
if (len(logins) == 0):
	final_cleanup(dbcnx, dbcur, ignore_apps, app_map)
	sys.exit(0)

print 'backing up %d duplicate logins' % len(logins)
logins_map = {}
for login in logins: logins_map[login[0]] = login[1]
lf = open('deleted-logins-map', 'w')
lf.write(str(logins_map))
lf.close()
logins_map.clear()

# save duplicate logins for readd step below
if (ignore_apps):
	if (case_sensitive):
		dbcur.execute('select ts_login_name,ts_app_id,ts_apptype_id,ts_user_id,ts_raw_login_name,ts_create_date from ts_user_logins_map where ts_soft_delete = false and ts_login_name in (select ts_login_name from ts_user_logins_map group by ts_login_name having count(*) > 1) order by ts_login_name,ts_create_date')
	else:
		dbcur.execute('select ts_login_name,ts_app_id,ts_apptype_id,ts_user_id,ts_raw_login_name,ts_create_date from ts_user_logins_map where ts_soft_delete = false and lower(ts_login_name) in (select lower(ts_login_name) from ts_user_logins_map group by lower(ts_login_name) having count(*) > 1) order by ts_login_name,ts_create_date')
	logins = dbcur.fetchall()
else:
	# get dups for case sensitive apps
	dbcur.execute('select ts_login_name,ts_app_id,ts_apptype_id,ts_user_id,ts_raw_login_name,ts_create_date from ts_user_logins_map where ts_soft_delete = false and ts_login_name in (select ts_login_name from ts_user_logins_map where ts_app_id in (select ts_id from ts_apps where ts_case_sensitivity_login_name=true) group by ts_app_id,ts_login_name having count(*) > 1) order by ts_login_name,ts_app_id,ts_create_date')
	logins = dbcur.fetchall()

	# get dups for case insensitive apps
	dbcur.execute('select ts_login_name,ts_app_id,ts_apptype_id,ts_user_id,ts_raw_login_name,ts_create_date from ts_user_logins_map where ts_soft_delete = false and lower(ts_login_name) in (select lower(ts_login_name) from ts_user_logins_map where ts_app_id in (select ts_id from ts_apps where ts_case_sensitivity_login_name=false) group by ts_app_id,lower(ts_login_name) having count(*) > 1) order by ts_login_name,ts_app_id,ts_create_date')
	logins += dbcur.fetchall()

print 'removing %d duplicate logins' % len(logins)
if (ignore_apps):
	if (case_sensitive):
		dbcur.execute('delete from ts_user_logins_map where ts_login_name in (select ts_login_name from ts_user_logins_map group by ts_login_name having count(*) > 1)')
	else:
		dbcur.execute('delete from ts_user_logins_map where lower(ts_login_name) in (select lower(ts_login_name) from ts_user_logins_map group by lower(ts_login_name) having count(*) > 1)')
else:
	# delete dups for case sensitive apps
	dbcur.execute('delete from ts_user_logins_map where ts_login_name in (select ts_login_name from ts_user_logins_map where ts_app_id in (select ts_id from ts_apps where ts_case_sensitivity_login_name=true) group by ts_app_id,ts_login_name having count(*) > 1)')

	# delete dups for case insensitive apps
	dbcur.execute('delete from ts_user_logins_map where lower(ts_login_name) in (select lower(ts_login_name) from ts_user_logins_map where ts_app_id in (select ts_id from ts_apps where ts_case_sensitivity_login_name=false) group by ts_app_id,lower(ts_login_name) having count(*) > 1)')
dbcnx.commit()

# readd oldest non-soft-deleted duplicate login name for each app
inserts = 0
for login in logins:
	aid = login[1]
	if (ignore_apps):
		if (case_sensitive):
			login_name = login[0]
		else:
			login_name = login[0].lower()
	elif (app_map[aid]):
		login_name = login[0]
	else:
		login_name = login[0].lower()

	try:
		apps_map = logins_map[login_name]
	except KeyError:
		apps_map = {}
		apps_map[login[1]] = login[2:]
		logins_map[login_name] = apps_map
	else:
		if (not ignore_apps and not apps_map.has_key(login[1])): apps_map[login[1]] = login[2:]

print 'readding 1 login per app (%d duplicates)' % len(logins_map.items())
for login in logins_map.items():
	login_name = login[0]
	apps_map = login[1]
	for app in apps_map.items():
		cols = app[1]
		app_id = app[0]
		dbcur.execute("insert into ts_user_logins_map(ts_login_name, ts_app_id, ts_apptype_id, ts_user_id, ts_raw_login_name, ts_create_date, ts_delete_date, ts_soft_delete, version_info) values ('%s', %d, %d, %d, '%s', '%s', null, false, 0)" % (login_name,app_id,cols[0],cols[1],cols[2],str(cols[3])))
		inserts += 1
		if (inserts % 1000 == 0): print '%d rows inserted' % inserts

if (inserts > 0):
	dbcnx.commit()
	print '%d rows inserted' % inserts


# remap the defects and logins to the oldest user id for a duplicate login
print 'remapping defects and stats for duplicate logins'
i = updates = 0
while (i < len(logins)):
	login = logins[i]
	login_name = login[0]
	app_id = login[1]
	to_uid = login[3]
	dbcur.execute("select ts_incarnation_id from ts_users where ts_id = %d" % to_uid)
	to_uiid = dbcur.fetchall()[0][0]

	# construct list of user ids to be changed
	j = i + 1
	from_uids = []
	while (j < len(logins) and login_name == logins[j][0] and (ignore_apps or app_id == logins[j][1])):
		from_uids += [logins[j][3]]
		j += 1

	# do updates in groups of 1000 (to avoid query length problems)
	k = 0
	while (k < len(from_uids)):
		from_uids_str = str(tuple(from_uids[k:k+1000])).replace('L', '').replace(',)', ')')

		rows = dbcur.execute("update ts_defects set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates

		rows = dbcur.execute("update ts_defects_interval set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates

		rows = dbcur.execute("update ts_stats_transet_user_daily set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		rows = dbcur.execute("update ts_stats_transet_user_interval set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		rows = dbcur.execute("update ts_stats_transet_user_monthly set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		rows = dbcur.execute("update ts_stats_transet_user_weekly set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates

		rows = dbcur.execute("update ts_stats_transetgroup_user_daily set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		rows = dbcur.execute("update ts_stats_transetgroup_user_interval set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		rows = dbcur.execute("update ts_stats_transetgroup_user_monthly set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		rows = dbcur.execute("update ts_stats_transetgroup_user_weekly set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates

		rows = dbcur.execute("update ts_stats_tranunit_user_daily set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		rows = dbcur.execute("update ts_stats_tranunit_user_interval set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		rows = dbcur.execute("update ts_stats_tranunit_user_monthly set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		rows = dbcur.execute("update ts_stats_tranunit_user_weekly set ts_user_id = %d,ts_user_incarnation_id = %d where ts_user_id in %s" % (to_uid, to_uiid, from_uids_str))
		if (rows > 1):
			updates += rows
			if (updates % 1000 == 0): print "%d rows updated" % updates
		k += 1000

	i = j

dbcnx.commit()
print "%d rows updated" % (updates)

print 'deleting users of duplicate logins'
if (os.spawnlp(os.P_WAIT, 'sh', 'sh', 'drop-user-constraints.sh') == 0):
	i = deletes = last_print = 0

	while (i < len(logins)):
		login = logins[i]
		login_name = login[0]
		app_id = login[1]

		# construct list of user ids to be changed
		j = i + 1
		from_uids = []
		while (j < len(logins) and login_name == logins[j][0] and (ignore_apps or app_id == logins[j][1])):
			from_uids += [logins[j][3]]
			j += 1

		# delete the remapped users (in groups of 1000 to avoid query length issues)
		k = 0
		while (k < len(from_uids)):
			from_uids_str = str(tuple(from_uids[k:k+1000])).replace('L', '').replace(',)', ')')
			deletes += dbcur.execute("delete from ts_users where ts_id in %s" % from_uids_str)
			if (deletes - last_print > 1000):
				print "%d users deleted" % deletes
				last_print = deletes
			k += 1000

		i = j

	print "%d users deleted" % (deletes)
	if (deletes > 0): dbcnx.commit()

	if (os.spawnlp(os.P_WAIT, 'sh', 'sh', 'add-user-constraints.sh') != 0):
		print "*** can't readd user constraints ***"

final_cleanup(dbcnx, dbcur, ignore_apps, app_map)
