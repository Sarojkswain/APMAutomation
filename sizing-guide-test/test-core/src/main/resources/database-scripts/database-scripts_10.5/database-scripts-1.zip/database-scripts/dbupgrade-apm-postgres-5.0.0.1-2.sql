-- Updating database from 5.0.0.1 to 5.0.0.2

update ts_domains set ts_db_versions='5.0.0.2';
