#!/bin/sh

# This sets up a database for PostgreSQL by running the following steps:
#   - It creates the "admin" user if it doesn't already exist.
#   - It creates the "cemdb" database if it doesn't already exist.

set -e

dbserverhost=$1
dbinstalldir=$2
dbname=$3

# User postgres
dbserviceuser=$4
dbservicepwd=$5

# User admin
dbadminuser=$6 
dbadminpwd=$7

if [ $# -lt 7 ]; then
  echo "Arguments required <dbserverhost> <dbinstalldir> <dbname> <dbserviceuser> <dbservicepwd> <dbadminuser> <dbadminpwd> <dbport <optional>>"
  echo "dbinstalldir: complete path where the database is installed excluding the bin dir. "
  echo "eg: /opt/database/postgres/9.2-pgdg "
  exit
fi

# set the dbport to default 5432
if [ $# -eq 8 ]; then
  dbport=$8
else
  dbport="5432"
fi

echo "setting path from dbinstalldir $dbinstalldir"
PATH=$dbinstalldir/postgres/9.2-pgdg/bin/64:$dbinstalldir/bin:$dbinstalldir/bin/64:$PATH
export PATH
LD_LIBRARY_PATH=$dbinstalldir/postgres/9.2-pgdg/lib/64:$dbinstalldir/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH
echo "PATH is $PATH"
echo "LD_LIBRARY_PATH is $LD_LIBRARY_PATH"



# Create the "admin" user if it doesn't already exist.
if PGUSER="$dbserviceuser" PGPASSWORD="$dbservicepwd" psql -h $dbserverhost -p $dbport -d template1 -c "select * from pg_catalog.pg_user where usename = '$dbadminuser'" | \
    grep -i '1 row' > /dev/null; then
  echo "User $dbadminuser already exists"
else
  echo "Creating user $dbadminuser"
  PGUSER="$dbserviceuser" PGPASSWORD="$dbservicepwd" psql -h $dbserverhost -p $dbport -d template1 -c "create user $dbadminuser password '$dbadminpwd';"
fi

# Create the specified database if it doesn't already exist.
if PGUSER="$dbserviceuser" PGPASSWORD="$dbservicepwd" psql -h $dbserverhost -p $dbport -d $dbname -f /dev/null 2> /dev/null; then
  echo "Database $dbname already exists"
else
  echo "Creating database $dbname with the $dbadminuser user as the owner."
  PGUSER="$dbserviceuser" PGPASSWORD="$dbservicepwd" createdb -h $dbserverhost -p $dbport -E unicode -O "$dbadminuser" "$dbname"
fi

#verify if this is linux platform
platform=`uname -a | cut -f1 -d' '`
if [ "$platform" = "Linux" ] && [ "$USER" = "root" ]; then
  # Create lang. is NOT necessary on Linux when user is root.
  echo "skip creating lang"
elif PGUSER="$dbserviceuser" PGPASSWORD="$dbservicepwd" psql -h $dbserverhost -p $dbport -d $dbname -c "SELECT * FROM pg_catalog.pg_language WHERE lanname='plpgsql'" | \
  grep -i '1 row' > /dev/null; then
  echo "language plpgsql is already installed"
else
  # Create lang. is necessary when 8.4 db is installed on BOTH Linux and Solaris platform (except above).
  PGUSER="$dbserviceuser" PGPASSWORD="$dbservicepwd" createlang -p "$dbport" plpgsql "$dbname"
  echo "lang plpgsql created"
fi

# save the exit code
savedrc=$?
# Turn off shell exit immediatelly option
# The following odbc setting command might fail when using non-root user account.
# But it can be ignored and the script should proceed.
set +e

# create an odbc data source for this newly created database
# run this check only if platform is linux and is 32 bit

bits=`uname -a | cut -f14 -d' '`

if [ "$platform" = "Linux" ] && [ "$bits" = "i386" ]
then
	echo "checking if TSDSN_$dbname exists"
		rc=`odbcinst -q -s | grep TSDSN_$dbname | wc -l`

		if [ $rc -eq 0 ] 
		then	
			if [ -r ./PostgresTSDSNTemplate.ini ]; then
				# substitute ini properties with appropriate values
				sed -e "s/TSDSN/TSDSN_$dbname/" -e "s/cemdb/$dbname/" \
				    -e "s/localhost/$dbserverhost/" -e "s/5432/$dbport/" ./PostgresTSDSNTemplate.ini > ./TSDSNtemp.ini
				if [ ! -f ./TSDSNtemp.ini ]; then
					echo "Failed to create TSDSN temp file, please ensure you have the permission."
				fi

				echo "Creating System DSN TSDSN_$dbname" 
				odbcinstrc=`odbcinst -i -s -l -f ./TSDSNtemp.ini`

				if [ $odbcinstrc -eq 0 ]; then	
					# delete temporary ini
					rm -f ./TSDSNtemp.ini
				else
					echo "Failed to create System DSN TSDSN_$dbname in odbc.ini file."
					echo "You may need root priviledge to create it."
					savedrc=$odbcinstrc
				fi
			else
				echo "Missing ./PostgresTSDSNTemplate.ini file."
			fi
		else
			echo "TSDSN_$dbname is already defined."
		fi
else
   echo " Platform is not a 32 bit linux platform hence skipped installing python odbc drivers "
   
fi

echo "returning exit code" $savedrc
exit $savedrc
