-- index names are of the form: <table name>_<index name>
DROP INDEX application_server_name_index;
DROP INDEX agent_name_index; 
DROP INDEX owner_name_index;
DROP INDEX vertex_name_index; 
DROP INDEX vertex_typename_index;
