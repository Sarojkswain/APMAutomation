ALTER TABLE appmap_settings
  RENAME TO appmap_old_settings;

CREATE TABLE appmap_settings (
        id VARCHAR(256) NOT NULL,
        user_id INTEGER,
        type INTEGER NOT NULL,
        data TEXT,
        created_at TIMESTAMP NOT NULL,
        updated_at TIMESTAMP NOT NULL,
        deleted_at TIMESTAMP,
        PRIMARY KEY(id)
);

INSERT INTO appmap_settings (id, user_id, type, data, created_at, updated_at, deleted_at)
  SELECT 'PE' || id, user_id, type, data, created_at, updated_at, deleted_at
  FROM appmap_old_settings
  WHERE type = 1;


INSERT INTO appmap_settings (id, user_id, type, data, created_at, updated_at, deleted_at)
  SELECT 'DP' || id, user_id, type, data, created_at, updated_at, deleted_at
  FROM appmap_old_settings
  WHERE type = 100;
  
DROP TABLE appmap_old_settings;

CREATE SEQUENCE seq_appmap_settings MINVALUE 1;
ALTER SEQUENCE seq_appmap_settings owned by appmap_settings.id;

CREATE INDEX appmap_settings_user_id_idx ON appmap_settings(user_id);
CREATE INDEX appmap_settings_type_idx ON appmap_settings(type, deleted_at);

DROP INDEX  appmap_vertices_time_idx;
DROP INDEX  appmap_vertices_service_idx;
DROP INDEX  appmap_vertices_app_idx;
DROP INDEX  appmap_vertices_attrib1_idx;
DROP INDEX  appmap_vertices_attrib2_idx;
DROP INDEX  appmap_vertices_attrib3_idx;
DROP INDEX  appmap_vertices_attrib4_idx;
DROP INDEX  appmap_vertices_attrib5_idx;
DROP INDEX  appmap_edges_idx;

DROP INDEX  appmap_edges_fk1_idx;
DROP INDEX  appmap_edges_fk2_idx;
DROP INDEX  appmap_edges_fk3_idx;


ALTER TABLE appmap_vertices DROP COLUMN search_attrib1,
                            DROP COLUMN search_attrib2,
                            DROP COLUMN search_attrib3,
                            DROP COLUMN search_attrib4,
                            DROP COLUMN search_attrib5,
                            DROP COLUMN application_id;
ALTER TABLE appmap_vertices ADD COLUMN fork BIGINT NOT NULL DEFAULT 0;
ALTER TABLE appmap_vertices ALTER COLUMN fork DROP DEFAULT;

CREATE TABLE appmap_attribs (
        vertex_id INTEGER NOT NULL,
        start_time TIMESTAMP NOT NULL,
        end_time TIMESTAMP NOT NULL,
        fork BIGINT NOT NULL,
        attrib_name VARCHAR(256),
        value VARCHAR(1024),
        PRIMARY KEY(vertex_id, start_time, attrib_name)
);


ALTER TABLE appmap_edges ADD COLUMN attributes TEXT,
                         ADD COLUMN fork BIGINT NOT NULL DEFAULT 0,
                         ADD COLUMN checkpoint CHAR;
                         
ALTER TABLE appmap_edges ALTER COLUMN fork DROP DEFAULT;

ALTER TABLE appmap_id_mappings ADD COLUMN attributes TEXT;                          
                         

alter table appmap_attribs
    add constraint appmap_attribs_vertex_fk
    foreign key (vertex_id, start_time)
    references appmap_vertices on delete cascade;  


CREATE INDEX appmap_vertices_time1_idx ON appmap_vertices(fork, end_time, start_time, vertex_id);
CREATE INDEX appmap_vertices_service1_idx ON appmap_vertices(fork, business_service, end_time, start_time, vertex_id);
CREATE INDEX appmap_attribs1_idx ON appmap_attribs(fork, attrib_name, end_time, start_time, value, vertex_id);
CREATE UNIQUE INDEX appmap_edges1_idx ON appmap_edges(fork, end_time, start_time, source_id, target_id, transaction_id);

CREATE INDEX appmap_edges_fk1_idx ON appmap_edges(fork, source_id, end_time, start_time);
CREATE INDEX appmap_edges_fk2_idx ON appmap_edges(fork, target_id, end_time, start_time);
CREATE INDEX appmap_edges_fk3_idx ON appmap_edges(fork, transaction_id, end_time, start_time);
CREATE INDEX appmap_edges_chk_idx ON appmap_edges(checkpoint, fork, end_time, start_time, transaction_id);

DROP TABLE appmap_intelli_senses;
CREATE INDEX ts_defect_meta_keys_NameIdx ON ts_defect_meta_keys (ts_name);

CREATE TABLE APM_GEOLOCATION (
        ip_start numeric(20) NOT NULL,
        ip_end numeric(20) NOT NULL,
        country varchar(100) NOT NULL,
        stateprov varchar(100),
        city varchar(100),
        version numeric(10) NOT NULL,
        PRIMARY KEY (ip_start)
);

CREATE TABLE APM_GEOLOCATION_METADATA (
        version numeric(10) NOT NULL,
        import_start_time timestamp with time zone NOT NULL,
        import_end_time timestamp with time zone,
        imported_file_name VARCHAR(100),
        processed_rows numeric(10),
        valid_rows numeric(10),
        invalid_rows numeric(10),
        import_successful bool NOT NULL,
        PRIMARY KEY (version)
);


CREATE TABLE apm_secure_store(
		alias VARCHAR(256) NOT NULL,
		cipher_text TEXT NOT NULL,
		created_date TIMESTAMP NOT NULL,
		last_read_date TIMESTAMP,
		client_id VARCHAR(256) NOT NULL,
		user_id VARCHAR(256) NOT NULL,	
		PRIMARY KEY (alias,user_id)
);

--initialize geolocation group settings
insert into ts_settings (ts_id, version_info, ts_key, ts_value, ts_description, ts_default, ts_soft_delete) values(DEFAULT, 1, 'btstats.geolocationprocessing', 'false', 'enable/disable Geo Location processing', 'false',false);
insert into ts_settings (ts_id, version_info, ts_key, ts_value, ts_description, ts_default, ts_soft_delete) values(DEFAULT, 1, 'btstats.geolocationgranularity', '2', 'Select Geo Location granularity', '2',false);
