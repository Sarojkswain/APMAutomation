-- Truncate table TS_USER_SESSIONS_MAP for FIPS Settings
truncate table ts_user_sessions_map;
