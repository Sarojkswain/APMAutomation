#!/bin/sh

# This script is run by the db import program to create the database tables for the import.

postgresServer=$1
postgresDbInstallDir=$2
postgresDbName=$3
postgresDbUser=$4
postgresDbPassword=$5
postgresDBPort=$6
postgresDBScriptsVer=$7

if [ $# -lt 7 ]; then
  echo "Required arguments <dbserverhostip> <dbinstalldir> <dbname> <dbuser> <dbpassword> <dbport> <dbScriptVer<optional>>"
  exit
fi

if [ -z "$7" ]; then
   postgresDBScriptsVer=5.0.0
fi

export PATH="$postgresDbInstallDir/bin:$PATH"


# db versions are of the form: d.d.d; create table scripts are only available for major versions, i.e. d.d.0
majorDbVersion=$(echo "$postgresDBScriptsVer" | sed 's/\([0-9][0-9]*\.[0-9][0-9]*\.\)[0-9][0-9]*[\.]*[0-9]*/\10/')

# cd to this program's directory because that's where the other scripts live
dir="$(dirname $0)"
if [ -n "$dir" ]; then cd "$dir" || exit 1; fi

# create the tables for this database version
echo "Importing a $majorDbVersion configuration"
PGUSER=$postgresDbUser PGPASSWORD="$postgresDbPassword" psql -h $postgresServer -p "$postgresDBPort" -d "$postgresDbName" -f "../createtables-postgres-$majorDbVersion.sql" 1>/dev/null 2>&1 \
  && sh setdefaults-postgres.sh "$postgresDbInstallDir" "$postgresDbName" "$postgresDbUser" "$postgresDbPassword" "$postgresDBPort" "$majorDbVersion" 1>/dev/null 2>&1

# changing sequence script file to majorDbVersion
sequenceScriptFile=../createsequences-postgres-$majorDbVersion.sql

if [ -r "$sequenceScriptFile" ]; then
  PGUSER="$postgresDbUser" PGPASSWORD="$postgresDbPassword" psql -h $postgresServer -p "$postgresDBPort" -d "$postgresDbName" -f "$sequenceScriptFile" 1>/dev/null 2>&1
fi

PGUSER="$postgresDbUser" PGPASSWORD="$postgresDbPassword" psql -h $postgresServer -p "$postgresDBPort" -d "$postgresDbName" -f "../quartz-1.5.1-postgres.sql" 1>/dev/null 2>&1

# do any upgrades necessary to make this database the same as the exported one
python dbupgrade-postgres.py $postgresDBScriptsVer TSDSN_$postgresDbName $postgresDbUser $postgresDbPassword 

