-- appmap
DROP TABLE IF EXISTS appmap_id_mappings, appmap_vertices, appmap_attribs, appmap_edges, appmap_settings,
					 appmap_model_vertices CASCADE;
DROP TABLE IF EXISTS appmap_api_keys;
DROP TABLE IF EXISTS apm_secure_store;
-- /appmap
