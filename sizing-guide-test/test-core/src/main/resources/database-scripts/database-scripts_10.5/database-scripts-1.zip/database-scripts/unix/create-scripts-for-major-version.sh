#!/bin/bash

# create scripts for a new major CEM (EM) version

usage()
{
  echo "$pgm new-version [host [user [client]]]"
  echo "  new-version  new major version number, e.g. 9.5"
  echo "  host         optional perforce host, e.g. cem-zeus:1666; default: P4PORT"
  echo "  user         optional perforce user; default: P4USER"
  echo "  client       optional perforce client (aka workspace); default: P4CLIENT"
  echo
  echo "run this in the directory in which you find it by 1st cd'ing to that directory"
  exit 1
}

create_scripts()
{
  # add the new scripts to the changelist
  for old_file in `find . -name '*9.1.0.0.sql'` ; do
    new_file=`echo $old_file|sed "s/$old_version/$new_version/"`
    cp "$old_file" "$new_file"
    chmod 644 "$new_file"
    p4 add -c "$CLN" "$new_file" 2>&1 1>/dev/null
  done

  # update the db version
  echo ,s/$old_version/$new_version/g$'\n'wq$'\n' | ed -s $(find . -name "initdb*$new_version.sql")
}


#---------------------------------------------------------------------------------


set -e
pgm="$(basename $0)"

# the new version number is required
if [ $# -lt 1 ]; then
  usage
fi

# validate new version; expecting d.d
new_version=`echo "$1" | sed 's/^\([0-9]*\)\.\([0-9]*\)$/\1.\2.0.0/'`
if [ "${#1}" -eq "${#new_version}" ]; then
  usage
fi

# punt if the any of the files already exist
for file in `find . -name "*$new_version.sql"` ; do
  echo "$new_version already exists"
  exit 1
done

old_version=`find . -name 'createtables-*.sql'|sort|tail -1|sed 's/\.\/createtables-[a-zA-Z]*-\([0-9.]*\)\.sql/\1/'`

# set the connection params
P4PORT=$P4PORT
P4USER=$P4USER
P4CLIENT=$P4CLIENT

# use the command params if supplied
if [ -n "$2" ]; then
  P4PORT="$2";
fi
if [ -n "$3" ]; then
  P4USER="$3";
fi
if [ -n "$4" ]; then
  P4CLIENT="$4";
fi

# punt if missing any P4 values
if [ -z "$P4PORT" ] || [ -z "$P4USER" ] || [ -z "$P4CLIENT" ]; then
  usage
fi

# login
echo perforce login...
if ! p4 login; then
  exit 1
fi

# create a changelist for these scripts
descr="$new_version database scripts"
resp=`echo Change:new$'\n'Client:apm_branch_main_coxbr02$'\n'User:coxbr02$'\n'Description:$descr | p4 change -i`
echo $resp
CLN=`echo $resp|sed 's/^Change \([0-9]*\) .*$/\1/'`

# create the new files and add them to the changelist
pushd ../
create_scripts
cd ../oracle/database-scripts
create_scripts
popd
