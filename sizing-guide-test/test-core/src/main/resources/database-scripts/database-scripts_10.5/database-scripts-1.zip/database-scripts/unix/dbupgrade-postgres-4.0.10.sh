#!/bin/sh

# This sets up the tables in the cemdb database for PostgreSQL.

set -e

dbserverip=$1
dbinstalldir=$2
dbname=$3
dbadminuser=$4
dbadminpwd=$5
dbversion=$6

if [ $# -lt 6 ]; then
  echo "Arguments required <dbserverip> <dbinstalldir> <dbname> <dbadminuser> <dbadminpwd> <schemaversion> [dbport]"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 7 ]; then
  dbport=$7
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"

#update PYTHONPATH so that egenix modules installed under python2.3 path are guaranteed to be picked up
export PYTHONPATH="$PYTHONPATH:/usr/lib/python2.3/site-packages"

echo 'Upgrading 4.0.10 to 4.1.0'
python dbupgrade-postgres-4.0.10.py TSDSN_$dbname "$dbadminuser" "$dbadminpwd"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d "$dbname" -f "../dbupgrade-postgres-4.0.10.sql"
