#!/bin/bash

# This script sets up the App Map tables in the cemdb database for PostgreSQL.

set -e

dbserverip=$1
dbinstalldir=$2
dbname=$3
dbadminuser=$4
dbadminpwd=$5
dbport=$6
dbversion=$7

if [ $# -lt 5 ]; then
  echo "Required arguments [dbserverhostip] [dbinstalldir] [dbname] [dbuser] [dbpassword] [dbport<optional: [default :5432]>] [dbScriptVer <optional: [default:5.0.0]>]"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 6 ]; then
  dbport=$6
else
  dbport="5432"
fi

# set the dbversion to default 10.5.1.0
if [ $# -eq 7 ]; then
  dbport=$6
  dbversion=$7
else
  dbversion="10.5.1.0"
fi


export PATH="$dbinstalldir/bin:$PATH"

if [ ! -e "../create-apm-tables-postgres-$dbversion.sql" ]; then
  echo "SQL scripts to create schema version $dbversion not found"
  exit
fi

APM="APM"

echo "$APP_MAP Schema $dbversion initialization and Creation of $APP_MAP tables started...."

PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d $dbname -f "../create-apm-tables-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d $dbname -f "../create-apm-sequences-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d $dbname -f "../add-apm-indexes-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d $dbname -f "../add-apm-constraints-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d $dbname -f "../add-apm-pruning-function-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d $dbname -f "../apm-defaults-postgres-$dbversion.sql"
echo "$APM Schema $dbversion initialization is completed"
