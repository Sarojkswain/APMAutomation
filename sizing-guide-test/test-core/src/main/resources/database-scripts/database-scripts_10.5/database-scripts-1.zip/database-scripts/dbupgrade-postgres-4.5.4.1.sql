-- update database from 4.5.4.1 to 4.5.4.2

-- Updating database version
update ts_domains set ts_db_versions='4.5.4.2';
