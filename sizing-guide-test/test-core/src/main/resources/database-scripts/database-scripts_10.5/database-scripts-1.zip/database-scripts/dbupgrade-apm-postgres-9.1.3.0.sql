alter table ts_biz_events add column ts_deleted_defects int DEFAULT 0;
