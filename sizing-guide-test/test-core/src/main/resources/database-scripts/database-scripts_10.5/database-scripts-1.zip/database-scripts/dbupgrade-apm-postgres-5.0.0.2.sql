-- Updating database from 5.0.0.2 to 5.0.0.3

update ts_domains set ts_db_versions='5.0.0.3';
