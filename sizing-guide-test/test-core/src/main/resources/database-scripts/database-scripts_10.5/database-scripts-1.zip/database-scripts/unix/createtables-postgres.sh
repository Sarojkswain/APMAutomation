#!/bin/bash

# This sets up the tables in the cemdb database for PostgreSQL.

set -e

dbserverhost=$1
dbinstalldir=$2
dbname=$3
dbadminuser=$4
dbadminpwd=$5
dbversion=$6

if [ $# -lt 6 ]; then
  echo "Arguments required <dbserverhost> <dbinstalldir> <dbname> <dbadminuser> <dbadminpwd> <schemaversion> <dbport <optional>>"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 7 ]; then
  dbport=$7
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"

if [ ! -e "../createtables-postgres-$dbversion.sql" ]; then
  echo "SQL scripts to create schema version $dbversion not found"
  exit
fi

echo 'Creating tables'
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverhost -p $dbport -d $dbname -f "../createtables-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverhost -p $dbport -d $dbname -f "../createsequences-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverhost -p $dbport -d $dbname -f "../addindexes-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverhost -p $dbport -d $dbname -f "../addconstraints-postgres-$dbversion.sql"
# new in 3.3
if [ -e "../addviews-postgres-$dbversion.sql" ]; then
  PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverhost -p $dbport -d $dbname -f "../addviews-postgres-$dbversion.sql"
fi
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverhost -p $dbport -d $dbname -f ../quartz-1.5.1-postgres.sql

echo 'Setting default column values'
if [ -e "../defaults-$dbversion.sql" ]; then
  PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverhost -p $dbport -d $dbname -f "../defaults-$dbversion.sql"
else
  sed -e '/^#/d' -e '/^ *$/d'\
 -e 's/^\([^ ]*\) *\([^ ]*\) *\(.*\)/alter table \1 alter column \2 set default \3;/' ../defaults-$dbversion.txt | PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverhost -p $dbport -d $dbname
fi
  

echo 'Initializing tables'
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverhost -p $dbport -d $dbname -f ../initdb-postgres-$dbversion.sql

echo "Schema $dbversion initialization is complete"
