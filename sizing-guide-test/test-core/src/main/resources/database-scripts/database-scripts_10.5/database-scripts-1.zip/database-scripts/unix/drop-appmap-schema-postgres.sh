#!/bin/bash

# This script sets up the App Map tables in the cemdb database for PostgreSQL.
# $1 = optional database version

set -e

dbinstalldir=$1
dbname=$2
dbadminuser=$3
dbadminpwd=$4
dbversion=$5

if [ $# -lt 5 ]; then
  echo "Arguments required <dbinstalldir> <dbname> <dbadminuser> <dbadminpwd> <schemaversion>"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 6 ]; then
  dbport=$6
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../drop-appmap-indexes-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../drop-appmap-constraints-postgres-$dbversion.sql"
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d $dbname -f "../drop-appmap-tables-postgres-$dbversion.sql"
