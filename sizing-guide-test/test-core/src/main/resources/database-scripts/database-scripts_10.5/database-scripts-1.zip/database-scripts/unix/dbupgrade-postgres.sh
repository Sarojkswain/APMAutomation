#!/bin/bash

# This gets the database schema version from the database
# and runs an upgrade script if an appropriate one exists.

# This is called from:
#  the top-level Tess install program

set -e

dbserverip=$1
dbinstalldir=$2
dbname=$3
dbadminuser=$4
dbadminpwd=$5
desired_database_version=$6


if [ $# -lt 6 ]; then
  echo "Arguments required <dbserverhostip> <dbinstalldir> <dbname> <dbadminuser> <dbadminpwd> <schemaversion> <dbport <optional>>"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 7 ]; then
  dbport=$7
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"

pgm="$(basename $0)"

# cd to this program's directory because that's where the upgrade
# programs and their data files live.
dir="$(dirname $0)"
if [ -n "$dir" ]; then cd "$dir" || exit 1; fi

# create a dsn for the database that is being upgraded
echo "checking if TSDSN_$dbname exists"
	rc=`odbcinst -q -s | grep TSDSN_$dbname | wc -l`
	
	if [ $rc -eq 0 ] 
	then	
		if [ -r ./PostgresTSDSNTemplate.ini ]; then
			# substitute ini properties with appropriate values
			sed -e "s/TSDSN/TSDSN_$dbname/" -e "s/cemdb/$dbname/" \
			    -e "s/localhost/$dbserverip/" -e "s/5432/$dbport/" ./PostgresTSDSNTemplate.ini > ./TSDNtemp.ini
		
			echo "Creating System DSN TSDSN_$dbname" 
	 		odbcinst -i -s -l -f ./TSDNtemp.ini
 		
 			# delete temporary ini
 			rm -f ./TSDNtemp.ini
 		else
 			echo "Missing ./PostgresTSDSNTemplate.ini file."
 		fi
	else
		echo "TSDSN_$dbname is already defined."
	fi

# Get the database version and store in $db_version, or exit on error.
get_db_version()
{
  # Make sure there is exactly one domain entry with id 1.
  n=$(PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql -q -t --pset format=unaligned -h $dbserverip -p $dbport -d "$dbname" -c 'select count(ts_db_versions) from ts_domains where ts_id=1;') || \
    exit 1

  if [ "$n" -ne 1 ]; then
    echo "$pgm: expecting 1 row in ts_domains with ts_id=1, found $n" 1>&2
    exit 1
  fi

  # Get the database version from the domain entry with id 1.
  db_version=$(PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql -q -t --pset format=unaligned -h $dbserverip -p $dbport -d "$dbname" -c 'select ts_db_versions from ts_domains where ts_id=1;')

  if [ -z "$db_version" ]; then
    echo "$pgm: database version is not defined" 1>&2
    exit 1
  fi

  echo "$pgm: database version is \"$db_version\""

  # Special case for databases that were converted from 2.4.  The
  # conversion program should have updated the ts_db_versions field
  # of the ts_domains row (with ts_id=1) but didn't.
  case "$db_version" in
    *2.4.0)
       echo "$pgm: treating db version \"$db_version\" as \"3.0.1\""
       db_version="3.0.1"
       ;;
  esac
}

# Keep track of all the versions encountered, so we don't get in
# a loop if some program sets the version incorrectly or forgets
# to set it.
declare -a all_db_versions

# Return true if $1 is an element of $all_db_versions.  Otherwise return false.
find_db_version()
{
  n=0
  while [ $n -lt ${#all_db_versions[*]} ]; do
    [ "${all_db_versions[$n]}" = "$1" ] && return 0  # found
    : $((++n))
  done
  return 1  # not found
}

# Run upgrade scripts until the database schema version is correct or
# we run out of scripts.
while :; do
  get_db_version
  if find_db_version "$db_version"; then
    echo "$pgm: error: database was previously version \"$db_version\"; there seems to be a loop"
    exit 1
  fi
  all_db_versions[${#all_db_versions[*]}]="$db_version"

  upgrade_program="./dbupgrade-postgres-$db_version.sh"

  upgrade_sql_file="../dbupgrade-postgres-$db_version.sql"
  if [ "$db_version" = "$desired_database_version" ]; then
    echo "$pgm: database version is correct"
    break
  elif [ -r "$upgrade_program" ]; then
    # If there is an upgrade program for this database version, run it
    # and exit on error.
    echo "$pgm: running $upgrade_program"
    
    sh "$upgrade_program" "$dbserverip" "$dbinstalldir" "$dbname" "$dbadminuser" "$dbadminpwd" "$db_version" "$dbport" 

    rc=$?
    echo "$pgm: $upgrade_program exited with status $rc"
    if [ "$rc" -ne 0 ]; then
      echo "$pgm: error in $upgrade_program; cannot continue" 1>&2
      exit 1
    fi
  elif [ -r "$upgrade_sql_file" ]; then
    # If there is an upgrade SQL script for this database version, run
    # psql on it and exit on error.
    echo "$pgm: running 'psql -f $upgrade_sql_file'"
    PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d "$dbname" -f "$upgrade_sql_file"
    rc=$?
    echo "$pgm: psql -f $upgrade_sql_file exited with status $rc"
    if [ "$rc" -ne 0 ]; then
      echo "$pgm: error running 'psql -f $upgrade_sql_file'; cannot continue" 1>&2
      exit 1
    fi
  else
    echo "$pgm: error: no program to upgrade database from version \"$db_version\""
    exit 0
  fi
done
exit 0
