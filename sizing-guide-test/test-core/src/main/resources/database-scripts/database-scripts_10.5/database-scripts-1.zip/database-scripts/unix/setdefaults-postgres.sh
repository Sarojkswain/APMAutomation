#!/bin/sh

# This defines default values for columns in tables in the database.
# $1 = optional database version

set -e

postgresDbInstallDir=$1
postgresDbName=$2
postgresDbUser=$3
postgresDbPassword=$4
postgresDBPort=$5
postgresDBScriptsVer=$6

if [ $# -lt 6 ]; then
  echo "Required arguments <dbinstalldir> <dbname> <dbuser> <dbpassword> <dbport> <dbScriptVer<optional>>"
  exit
fi

# set the database version
if [ $# -eq 6 ]; then
  postgresDBScriptsVer=$6
else
  postgresDBScriptsVer="5.0.0"
fi

export PATH="$postgresDbInstallDir/bin:$PATH"

defaultsScriptFile=../defaults-$postgresDBScriptsVer.sql
defaultsTxtFile=../defaults-$postgresDBScriptsVer.txt

if [ -r "$defaultsScriptFile" ]; then
  PGUSER=$postgresDbUser PGPASSWORD="$postgresDbPassword" psql -p "$postgresDBPort" -d "$postgresDbName" -f "$defaultsScriptFile" 1>/dev/null 2>&1  
elif [ -r "$defaultsTxtFile" ]; then
  sed -e '/^#/d' -e '/^ *$/d'\
 -e 's/^\([^ ]*\) *\([^ ]*\) *\(.*\)/alter table \1 alter column \2 set default \3;/' $defaultsTxtFile | PGUSER="$postgresDbUser" PGPASSWORD="$postgresDbPassword" psql --echo-all -d "$postgresDbName" -p "$postgresDBPort"
fi

echo Done setting defaults...
