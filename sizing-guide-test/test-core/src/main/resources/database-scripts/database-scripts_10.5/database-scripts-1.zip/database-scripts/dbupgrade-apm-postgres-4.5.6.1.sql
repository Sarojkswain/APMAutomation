-- update database from 4.5.6.1 to 9.0.5.0 for APM 9.0.5

-- Updating database version

update ts_domains set ts_db_versions='9.0.5.0';
