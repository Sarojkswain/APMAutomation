-- index names are of the form: <table name>_<index name>
DROP INDEX apm_agent_name_index;
DROP INDEX apm_agent_unique_index;
DROP INDEX apm_owner_uniue_index;
DROP INDEX apm_owner_name_index;
DROP INDEX apm_owner_type_index;
DROP INDEX apm_owner_transaction_id_index;
DROP INDEX apm_vertex_name_index;
DROP INDEX apm_vertex_unique_index;
DROP INDEX apm_vertex_typename_index;
DROP INDEX apm_edge_unique_index;
DROP INDEX apm_edge_owner_index;
DROP INDEX apm_edge_head_vertex_index;
DROP INDEX apm_edge_tail_vertex_index;
DROP INDEX apm_metric_path_vertex_id_indx;

