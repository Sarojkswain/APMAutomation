#!/usr/bin/env python
# the line above is for the UNIX environment
#
# cleanup duplicate rows in ts_user_logins_map (see bug 1960)

import os
import sys
import time
import mx.ODBC.unixODBC

# sort login by ts_raw_login_name and ts_create_date
def loginCmp(l1, l2):
	rc = cmp(l1[2].lower(), l2[2].lower())
	if (rc == 0): rc = cmp(l1[3], l2[3])
	return rc

# construct SQL necessary to re-insert a deleted row
def undoDelete(dbcur, sqlf, appid, login):
	sql = "select ts_user_id,ts_app_id,ts_apptype_id,ts_login_name,ts_raw_login_name,version_info,ts_create_date,ts_delete_date,ts_soft_delete from ts_user_logins_map where ts_app_id = %d and ts_login_name = '%s'" % (appid, login)
	dbcur.execute(sql)
	cols = list(dbcur.fetchone())
	cols[3] = cols[3].replace("\\","\\\\").replace("'","\\'")
	cols[4] = cols[4].replace("\\","\\\\").replace("'","\\'")
	if (cols[7] is None): cols[7] = 'null'
	if (cols[8]):
		cols[8] = 'true'
	else:
		cols[8] = 'false'
	sql = "insert into ts_user_logins_map(ts_user_id,ts_app_id,ts_apptype_id,ts_login_name,ts_raw_login_name,version_info,ts_create_date,ts_delete_date,ts_soft_delete) values (%d,%d,%d,'%s','%s',%d,'%s',%s,%s);\n" % tuple(cols)
	sqlf.write(sql)


dsn = 'TSDSN'
uid = 'admin'
pwd = 'quality'

# process any cmd line args
args = sys.argv[1:]
if (len(args) > 0):
	dsn = args[0]
if (len(args) > 1):
	uid = args[1]
if (len(args) > 2):
	pwd = args[2]

# connect to the database
dbcnx = mx.ODBC.unixODBC.Connect(dsn, uid, pwd)
dbcur = dbcnx.cursor()

# due to bug in dbupgrade-postgres.4.0.10.py, the PK of ts_user_logins_map may be missing
try:
	dbcur.execute('alter table ts_user_logins_map add constraint ts_user_logins_map_pkey primary key (ts_app_id, ts_login_name')
	dbcnx.commit()
except:
	pass


# cleanup database after bug 2027 (moveall creates rows in ts_usergroup_users_map with the same user incarnation id


# initialize the next available user incarnation id
print 'cleaning up duplicate user incarnation ids'
dbcur.execute('select max(ts_incarnation_id) from ts_users')
next_uiid = dbcur.fetchone()[0]
if (next_uiid is None): next_uiid = int(time.time())

# get the users that have 2+ rows in the usergroup users map with the same incarnation id
dbcur.execute('select distinct ts_user_id from ts_usergroup_users_map where ts_user_id in (select ts_user_id from ts_usergroup_users_map group by ts_user_id,ts_user_incarnation_id having count(*) >= 2)')
users = dbcur.fetchall()

# change the duplicate user incarnation ids for each affected user
updates = 0
for user in users:
	uid = str(user[0])

	# get the duplicate mappings for this user
	dbcur.execute('select ts_usergroup_id,ts_user_incarnation_id from ts_usergroup_users_map where ts_soft_delete = true and ts_user_id = ' + str(uid))
	maps = dbcur.fetchall()

	# change the duplicate incarnation ids
	for map in maps:
		updates += 1
		next_uiid += 1
		ugid = str(map[0])
		uiid = str(map[1])
		dbcur.execute('update ts_usergroup_users_map set ts_user_incarnation_id = %s where ts_usergroup_id = %s and ts_user_id = %s and ts_user_incarnation_id = %s' % (next_uiid, ugid, uid, uiid))

if (updates > 0): dbcnx.commit()


# cleanup database after 2051 - cleanup not commited

print 'removing temporary sequences'
dbcur.execute("select relname from pg_class where relname like 'ts_temp_seq_incarnation_id_%'")
names = dbcur.fetchall()
for name in names: dbcur.execute("drop sequence " + name[0])
if (len(names) > 0): dbcnx.commit()


# restore any deleted login names (see dbupgrade-postgres-4.0.10.py)

try : lf = open('deleted-logins-map')
except IOError, ex: pass
else:
	updates = 0
	logins_map = eval(lf.read())
	dbcur.execute("select ts_id from ts_users where ts_login_name = '???'")
	uids = dbcur.fetchall()
	print 'restoring deleted login names for %d users' % len(uids)

	for uid in uids:
		uid = uid[0]
		if (logins_map.has_key(uid)):
			updates += 1
			if (updates % 10000 == 0): print "updated %d users" % updates
			dbcur.execute("update ts_users set ts_login_name = '%s' where ts_id = %d" % (logins_map[uid], uid))

	if (updates > 0):
		print '%d login names restored' % updates
		dbcnx.commit()

	try: os.remove('deleted-logins-map')
	except: pass
