#!/usr/bin/env python
# the line above is for the UNIX environment
#
# partition the defects, meta values and tran details tables to fix slow deletes (TT50688)

import os
import sys
import time
import mx.ODBC.unixODBC


def create_partitions(day, date, date1, populate):

	# create partition on ts_defects
	print 'creating defect table partition for %s...' % date
	dbcur.execute("create table ts_defects_%s (check (ts_occur_date >= '%s' and ts_occur_date < '%s')) inherits (ts_defects)" % (day, date, date1))
	if (populate):
		dbcur.execute("insert into ts_defects_%s select * from ts_defects where ts_occur_date >= '%s' and ts_occur_date < '%s'" % (day, date, date1))
		dbcur.execute("select count(*) from ts_defects_%s" % day)
		cnt = dbcur.fetchone()
		print '%d rows added to ts_defects_%s' % (cnt[0], day)

	dbcur.execute("alter table ts_defects_%s add primary key(ts_id)" % day)
	dbcur.execute("create index ts_defects_%s_DateIndex on ts_defects_%s (ts_occur_date)" % (day, day))
	dbcur.execute("create index ts_defects_%s_DefectIndex on ts_defects_%s (ts_defect_def_id)" % (day, day))
	dbcur.execute("create index ts_defects_%s_EventIndex on ts_defects_%s (ts_biz_event_id)" % (day, day))

	dbcur.execute("alter table ts_defects_%s add constraint FK34AA2B6222B94AEE_%s foreign key (ts_tranunit_id) references ts_tranunits" % (day, day))
	dbcur.execute("alter table ts_defects_%s add constraint FK34AA2B629DADA24_%s foreign key (ts_transet_id) references ts_transets" % (day, day))
	dbcur.execute("alter table ts_defects_%s add constraint FK34AA2B62545ADA6D_%s foreign key (ts_user_id) references ts_users" % (day, day))
	dbcur.execute("alter table ts_defects_%s add constraint FK34AA2B62B62FC018_%s foreign key (ts_trancomp_id) references ts_trancomps" % (day, day))
	dbcur.execute("alter table ts_defects_%s add constraint FK34AA2B62C6CF0E07_%s foreign key (ts_monitor_id) references ts_monitors" % (day, day))
	dbcur.execute("alter table ts_defects_%s add constraint FK34AA2B62F081AE66_%s foreign key (ts_biz_event_id) references ts_biz_events" % (day, day))
	dbcur.execute("alter table ts_defects_%s add constraint FK34AA2B624AD9EEC4_%s foreign key (ts_defect_def_id) references ts_defect_defs" % (day, day))

	# create partition on ts_defect_meta_values
	print 'creating defect meta values table partition for %s...' % date
	dbcur.execute("create table ts_defect_meta_values_%s (check (ts_defect_date >= '%s' and ts_defect_date < '%s')) inherits (ts_defect_meta_values)" % (day, date, date1))
	if (populate):
		dbcur.execute("insert into ts_defect_meta_values_%s select * from ts_defect_meta_values where ts_defect_date >= '%s' and ts_defect_date < '%s'" % (day, date, date1))
		dbcur.execute("select count(*) from ts_defect_meta_values_%s" % day)
		cnt = dbcur.fetchone()[0]
		print '%d rows added to ts_defect_meta_values_%s' % (cnt, day)

	dbcur.execute("alter table ts_defect_meta_values_%s add primary key(ts_id)" % day)
	dbcur.execute("create index ts_defect_meta_values_%s_DefectIndex on ts_defect_meta_values_%s (ts_defect_id)" % (day, day))
	dbcur.execute("create index ts_defect_meta_values_%s_MetaKeyIndex on ts_defect_meta_values_%s (ts_metakey_id)" % (day, day))
	dbcur.execute("alter table ts_defect_meta_values_%s add constraint FKE00FC8E3955976_%s foreign key (ts_metakey_id) references ts_defect_meta_keys" % (day, day))

	# create partition on ts_tran_comp_details
	print 'creating tran comp details table partition for %s...' % date
	dbcur.execute("create table ts_tran_comp_details_%s (check (ts_defect_date >= '%s' and ts_defect_date < '%s')) inherits (ts_tran_comp_details)" % (day, date, date1))
	if (populate):
		dbcur.execute("insert into ts_tran_comp_details_%s select * from ts_tran_comp_details where ts_defect_date >= '%s' and ts_defect_date < '%s'" % (day, date, date1))
		dbcur.execute("select count(*) from ts_tran_comp_details_%s" % day)
		cnt = dbcur.fetchone()[0]
		print '%d rows added to ts_tran_comp_details_%s' % (cnt, day)

	dbcur.execute("alter table ts_tran_comp_details_%s add primary key(ts_id)" % day)
	dbcur.execute("create index ts_tran_comp_details_%s_DefectIndex on ts_tran_comp_details_%s (ts_defect_id)" % (day, day))
	dbcur.execute("create index ts_tran_comp_details_%s_TranCompIndex on ts_tran_comp_details_%s (ts_trancomp_id)" % (day, day))
	dbcur.execute("alter table ts_tran_comp_details_%s add constraint FK445D393922B94AEH_%s foreign key (ts_trancomp_id) references ts_trancomps on delete cascade" % (day, day))


#--------------------------------------------------------------------------------------


dsn = 'TSDSN'
uid = 'admin'
pwd = 'quality'

# process any cmd line args
args = sys.argv[1:]
if (len(args) > 0):
	dsn = args[0]
if (len(args) > 1):
	uid = args[1]
if (len(args) > 2):
	pwd = args[2]

# connect to the database
dbcnx = mx.ODBC.unixODBC.Connect(dsn, uid, pwd)
dbcur = dbcnx.cursor()

# update the query planner to prevent performance problems
print 'analyzing...'
dbcur.execute('analyze ts_defects')
dbcur.execute('analyze ts_defect_meta_values')
dbcur.execute('analyze ts_tran_comp_details')

# get the number of unique days in the defects table
print 'computing the number of days...'
dbcur.execute("select distinct date_trunc('day',ts_occur_date) from ts_defects order by date_trunc('day',ts_occur_date) desc")
dates = dbcur.fetchall()
print '%d days found' % len(dates)

# determine how many days to keep
dbcur.execute("select ts_transaction_defect_delete from ts_domains")
max_days = dbcur.fetchone()[0]
print '%d days will be kept' % max_days

# add and populate date col to meta values and tran details (much faster to partition)
print 'adding date columns...'
#dbcur.execute("alter table ts_defect_meta_values add column ts_defect_date timestamp")
#dbcur.execute("alter table ts_tran_comp_details add column ts_defect_date timestamp")
dbcur.execute("update ts_defect_meta_values set ts_defect_date=(select ts_occur_date from ts_defects where ts_id=ts_defect_id)")
dbcur.execute("update ts_tran_comp_details set ts_defect_date=(select ts_occur_date from ts_defects where ts_id=ts_defect_id)")

# partition defects, meta values and tran details tables by day
num_days = 0
for date in dates:
	date1 = str(date[0]+1)[0:10]
	date = str(date[0])[0:10]
	day = str(date)[0:10].replace('-','')
	create_partitions(day, date, date1, True)

	num_days += 1
	if (num_days >= max_days): break

# truncate the master tables
print 'truncating the master tables...'
dbcur.execute("truncate ts_defects cascade")
dbcur.execute("truncate ts_defect_meta_values cascade")
dbcur.execute("truncate ts_tran_comp_details cascade")

dbcnx.commit()

print 'dropping indexes and constaints on the master tables...'
try: dbcur.execute("drop index ts_defects_DateIndex")
except StandardError, ex: print "Can't delete index ts_defects_DateIndex: " + str(ex)
try: dbcur.execute("drop index ts_defects_DefectIndex")
except StandardError, ex: print "Can't delete index ts_defects_DefectIndex: " + str(ex)
try: dbcur.execute("drop index ts_defects_EventIndex")
except StandardError, ex: print "Can't delete index ts_defects_EventIndex: " + str(ex)
try: dbcur.execute("drop index ts_defect_meta_value_DefectIndex")
except StandardError, ex: print "Can't delete index ts_defect_meta_value_DefectIndex: " + str(ex)
try: dbcur.execute("drop index ts_defect_meta_value_MetaKeyIndex")
except StandardError, ex: print "Can't delete index ts_defect_meta_value_MetaKeyIndex: " + str(ex)
try: dbcur.execute("drop index ts_tran_comp_details_DefectIndex")
except StandardError, ex: print "Can't delete index ts_tran_comp_details_DefectIndex: " + str(ex)
try: dbcur.execute("drop index ts_tran_comp_details_TranCompIndex")
except StandardError, ex: print "Can't delete index ts_tran_comp_details_TranCompIndex: " + str(ex)
try: dbcur.execute("alter table ts_defect_meta_values drop constraint FKE00FC8E235F57ED")
except StandardError, ex: print "Can't drop constraint FKE00FC8E235F57ED: " + str(ex)
try: dbcur.execute("alter table ts_tran_comp_details drop constraint FK445D393922B94AEG")
except StandardError, ex: print "Can't drop constraint FK445D393922B94AEG: " + str(ex)

dbcnx.commit()
print 'done!'
