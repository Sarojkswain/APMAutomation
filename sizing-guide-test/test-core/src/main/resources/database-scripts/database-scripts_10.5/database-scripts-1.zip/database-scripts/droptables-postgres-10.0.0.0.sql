-- appmap
DROP TABLE IF EXISTS appmap_id_mappings, appmap_vertices, appmap_edges, appmap_intelli_senses, appmap_settings CASCADE;
-- /appmap
