#!/bin/bash
# runs the Upgrade Schema program

javaExe=../../../jre/bin/java
lib_dir=../lib

class_dir=../:$lib_dir/com.wily.apm.dbtools_10.5.1.jar:$lib_dir/org.apache.jakarta_log4j_1.2.15.jar:$lib_dir/postgresql-9.2-1003.jdbc4.jar:$lib_dir/commons-lang-2.1.jar:$lib_dir/commons-configuration-1.1.jar:$lib_dir/commons-logging-1.0.4.jar:$lib_dir/commons-cli-1.2.0.jar:$lib_dir/ojdbc6.jar

java_vm_args="-Dlog4j.configuration=../../common/config/log4j-dbtools.properties"

# run the upgrade schema program
"$javaExe" -Xms256M -Xmx512M -cp $class_dir $java_vm_args com.wily.apm.dbtools.upgradeschema.UpgradeSchema $*

