-- update database from 4.5.4.0 to 4.5.4.1

-- Updating database version
update ts_domains set ts_db_versions='4.5.4.1';
