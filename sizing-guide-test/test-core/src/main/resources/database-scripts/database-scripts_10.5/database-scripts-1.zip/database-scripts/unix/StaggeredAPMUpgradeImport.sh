#!/bin/sh

# This imports the tables in the cemdb database for the upgrade process
# $6 = optional db port

dbinstalldir=$1
dbbakfile=$2
dbname=$3
dbadminuser=$4
dbadminpwd=$5

if [ $# -lt 5 ]; then
  echo "Arguments required <dbinstalldir> <dbbakfile> <dbname> <dbadminuser> <dbadminpwd> <dbport <optional>>"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 6 ]; then
  dbport=$6
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"

# Get the database version from the domain entry with id 1.
db_version=$(PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" psql -q -t --pset format=unaligned -p $dbport -d "$dbname" -c 'select ts_db_versions from ts_domains where ts_id=1;')

if [ -z "$db_version" ]; then
	echo "$pgm: database version is not defined" 1>&2
	exit 1
fi

if [ "$db_version" != "5.0.0.0" ]; then
  echo "The script can only be run against a database of schema version 5.0"
  exit
fi

# import the tables

PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=apm_agent --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=apm_owner --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=apm_vertex_type --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=apm_vertex --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=apm_edge --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=apm_metric_path --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=apm_vertex_logical_equivalence --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_apps --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_tran_def_groups --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_transet_groups --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_bizdef_filters --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_monitors --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_recording_sessions --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_recording_components --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_transets --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_tranunits --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_trancomps --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_params --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_defect_defs --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" pg_restore -a --table=ts_transetgroup_transets_map --dbname="$dbname" --port=$dbport -U "$dbadminuser" "$dbbakfile"




# Update the sequences to bring them up to date after running init
updateSequenceFile=../dbupdate-sequences-postgres-5.0.0.sql
if [ -r "$updateSequenceFile" ]; then
	echo "$pgm: running 'psql -f $updateSequenceFile'"
	PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d "$dbname" -f "$updateSequenceFile"
fi

updateAPMSequenceFile=../dbupdate-apm-sequences-postgres-5.0.0.sql
if [ -r "$updateAPMSequenceFile" ]; then
	echo "$pgm: running 'psql -f $updateAPMSequenceFile'"
    PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" psql --echo-all -p $dbport -d "$dbname" -f "$updateAPMSequenceFile"
fi
