alter table apm_edge alter type set default 'RR';
