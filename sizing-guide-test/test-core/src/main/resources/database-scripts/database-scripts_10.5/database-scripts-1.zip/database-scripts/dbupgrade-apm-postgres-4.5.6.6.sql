-- Updating database version from 4.5.6.6 to 4.5.6.7

update ts_domains set ts_db_versions='4.5.6.7';
