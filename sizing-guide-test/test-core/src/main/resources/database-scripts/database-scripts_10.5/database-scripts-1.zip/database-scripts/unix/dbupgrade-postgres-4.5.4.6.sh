#!/bin/sh

# This sets up the tables in the cemdb database for PostgreSQL.

set -e

dbserverip=$1
dbinstalldir=$2
dbname=$3
dbadminuser=$4
dbadminpwd=$5
dbversion=$6

if [ $# -lt 6 ]; then
  echo "Arguments required <dbserverip> <dbinstalldir> <dbname> <dbadminuser> <dbadminpwd> <schemaversion> [dbport]"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 7 ]; then
  dbport=$7
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"

echo 'Installing PL/pgSQL'
PGUSER=$dbadminuser PGPASSWORD=$dbadminpwd createlang plpgsql -h $dbserverip -p $dbport -d $dbname && echo > /dev/null
echo 'Done'

echo 'Upgrading 4.5.4.6 to 5.0.0.0'
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d "$dbname" -f "../dbupgrade-postgres-4.5.4.6.sql"

#create apm schema
sh create-apm-schema-postgres.sh $dbserverip $dbinstalldir $dbname $dbadminuser $dbadminpwd $dbport

echo 'Create required sequences for needed tables'
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d "$dbname" -f "../createsequences-postgres-5.0.0.sql"

echo 'Initialize tables'
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d "$dbname" -f "../dbupgrade-initdb-postgres-4.5.4.6.sql"

echo 'Update the sequences with the current id values'
PGUSER=$dbadminuser PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip -p $dbport -d "$dbname" -f "../dbupdate-sequences-postgres-5.0.0.sql"
