#!/bin/sh

# This sets up the tables in the cemdb database for PostgreSQL.

set -e

dbserverip=$1
dbinstalldir=$2
dbname=$3
dbadminuser=$4
dbadminpwd=$5
dbversion=$6

if [ $# -lt 6 ]; then
  echo "Arguments required <dbserverip> <dbinstalldir> <dbname> <dbadminuser> <dbadminpwd> <schemaversion> [dbport]"
  exit
fi

# set the dbport to default 5432
if [ $# -eq 7 ]; then
  dbport=$7
else
  dbport="5432"
fi

export PATH="$dbinstalldir/bin:$PATH"

#update PYTHONPATH so that egenix modules installed under python2.3 path are guaranteed to be picked up
export PYTHONPATH="$PYTHONPATH:/usr/lib/python2.3/site-packages"

# rerun this because of patches for UBOC and Fidelity having the same db version but different schema
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" psql --echo-all  -h $dbserverip -p $dbport -d "$dbname" -f "../dbupgrade-postgres-4.2.0.sql"


echo 'Upgrading 4.2.3.0 to 4.5.0.0'
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" psql --echo-all -h $dbserverip  -p $dbport -d "$dbname" -f "../dbupgrade-postgres-4.2.3.0.sql"
python dbupgrade-postgres-4.2.3.0.py TSDSN_$dbname "$dbadminuser" "$dbadminpwd"

# if there are defects for today, create the tran comp details partition for today (tess won't at startup)
start_today=`date +%F`
num_defects=$(PGPASSWORD="$dbadminpwd" psql -U "$dbadminuser" -d "$dbname"  -h $dbserverip -p $dbport -q -t -c "select count(*) from ts_defects where ts_occur_date >= '$start_today'")
if [ $num_defects -gt 0 ]; then
  echo 'Creating tran comp details partition for today'
  start_date=`date +%F|sed 's/-//g'`
  end_date=`date -d tomorrow +%F|sed 's/-//g'`
  echo "create table ts_tran_comp_details_$start_date (check (ts_defect_date >= '$start_date' and ts_defect_date < '$end_date')) inherits (ts_tran_comp_details); create index ts_tran_comp_details_${start_date}_DefectIndex on ts_tran_comp_details_$start_date (ts_defect_id); create index ts_tran_comp_details_${start_date}_TranCompIndex on ts_tran_comp_details_$start_date (ts_trancomp_id); alter table ts_tran_comp_details_$start_date add constraint FK445D393922B94AEH_$start_date foreign key (ts_trancomp_id) references ts_trancomps on delete cascade" | PGPASSWORD="$admin_pwd" psql -a -U "$dbadminuser" -d "$dbname"  -h $dbserverip -p $dbport
fi

echo 'Reading views'
PGUSER="$dbadminuser" PGPASSWORD="$dbadminpwd" psql --echo-all  -h $dbserverip -p $dbport -d "$dbname" -f "../addviews-postgres-4.5.0.sql"


