-- upgrade from 10.5 to 10.5.1
TRUNCATE TABLE at_stories_pivot cascade;
ALTER TABLE at_stories_pivot ADD COLUMN context_id varchar(2048) not null;
ALTER TABLE at_evidences ALTER COLUMN vertex_id TYPE varchar(2048);
CREATE INDEX at_stories_context_idx ON at_stories_pivot(context_id);
